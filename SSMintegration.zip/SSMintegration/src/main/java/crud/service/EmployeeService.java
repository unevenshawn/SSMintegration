package crud.service;

import crud.bean.Employee;
import crud.dao.EmployeeMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;


@Service
public class EmployeeService {

    //Controller，Service和DAO层,service层调用DAO层
    @Autowired
    EmployeeMapper employeeMapper;


    public List<Employee> getAll() {
        //通过该方法查询出所有员工，但是数据很多，需要进行分页
        return employeeMapper.selectByExampleWithDept(null);

    }
}

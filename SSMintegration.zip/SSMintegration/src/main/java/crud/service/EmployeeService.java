package crud.service;

import crud.bean.Employee;
import crud.bean.EmployeeExample;
import crud.dao.EmployeeMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;


@Service
public class EmployeeService {

    //Controller，Service和DAO层,service层调用DAO层
    @Autowired
    EmployeeMapper employeeMapper;


    public List<Employee> getAll() {
        //通过该方法查询出所有员工，但是数据很多，需要进行分页
        return employeeMapper.selectByExampleWithDept(null);

    }

    public void save(Employee employee) {
        //insert方法对应的是连自增的字段都要提供信息
        employeeMapper.insertSelective(employee);

    }

    public int update(Employee employee){
        //ByPrimaryKeySelective一类的方法，只要使用，必须带上主键值
        int i = employeeMapper.updateByPrimaryKeySelective(employee);
        if (i!=0) return i;
        return 0;
    }

    public Employee getEmp(Integer id){
        Employee employee = employeeMapper.selectByPrimaryKeyWithDept(id);
        return employee;
    }

    //批量删除emps的方法，由于mybatis后半部分被我跳过了，所以这儿的批量删除，还有example的使用，我一概不知道怎么使用
    public void batchDelEmp(List<Integer> ids){
        //获取example对象
        EmployeeExample example = new EmployeeExample();
        EmployeeExample.Criteria criteria = example.createCriteria();
        //通过下面一行的方法，转换成sql => delete from employee where emp_id in (34,24,33,66);
        criteria.andEmpIdIn(ids);
        employeeMapper.deleteByExample(example);
    }

    public void delEmp(Integer id){
        employeeMapper.deleteByPrimaryKey(id);
    }


}

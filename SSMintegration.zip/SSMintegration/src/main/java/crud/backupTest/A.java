package crud.backupTest;

import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class A {
    public static void time() {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        long l = System.currentTimeMillis();
        String format = dateTimeFormatter.format(ZonedDateTime.now());
        System.out.println("current time"+format);
    }


}

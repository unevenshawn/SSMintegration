package crud.bean;

import org.apache.catalina.Context;
import org.apache.catalina.LifecycleException;
import org.apache.catalina.Server;
import org.apache.catalina.WebResourceRoot;
import org.apache.catalina.connector.Connector;
import org.apache.catalina.startup.Tomcat;
import org.apache.catalina.webresources.DirResourceSet;
import org.apache.catalina.webresources.StandardRoot;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import java.io.File;



public class RunTomcat {


    public static void main(String[] args) throws LifecycleException, ServletException {
        Tomcat tomcat =new Tomcat();
        tomcat.setPort(Integer.getInteger("port",8080));
        Connector connector = tomcat.getConnector();
        Context context;
        connector.setURIEncoding("utf-8");
        context = tomcat.addWebapp("",new File("src/main/webapp").getAbsolutePath());
        WebResourceRoot resources = new StandardRoot(context);
        resources.addPreResources( new DirResourceSet(resources, "/WEB-INF/classes", new File("target/classes").getAbsolutePath(), "/"));
        context.setResources(resources);
        tomcat.start();
        Server server = tomcat.getServer();
        server.await();
    }


}

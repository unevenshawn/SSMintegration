package crud.bean;

import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class Msg {
    //状态码
    private  int code;

    //提示信息
    private  String message;

    //用户要返回给浏览器的数据
    private Map<String,Object> map =new HashMap<>();



    public static Msg success(){
        Msg result=new Msg();
        result.setCode(200);
        result.setMessage("success");
        return result;
    }

    public  static Msg fail(){
        Msg result=new Msg();
        result.setCode(500);
        result.setMessage("fail");
        return result;
    }

    public Msg add(String key, Object value){
        this.map.put(key, value);
        return this;
    }





    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Map<String, Object> getMap() {
        return map;
    }

    public void setMap(Map<String, Object> map) {
        this.map = map;
    }
}

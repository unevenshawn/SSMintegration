package crud.controller;

import com.google.gson.Gson;
import crud.bean.Department;
import crud.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;


//处理与部门有关请求
@Controller
public class DeptController {

    @Autowired
    private DepartmentService departmentService;

    @ResponseBody
    @RequestMapping(value = "/depts",produces = {"text/html;charset=UTF-8;","application/json;"})
    public String getDepts(){
        List<Department> departmentList=departmentService.getDepts();
        return new Gson().toJson(departmentList);
    }

}

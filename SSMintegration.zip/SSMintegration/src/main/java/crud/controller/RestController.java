package crud.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.gson.Gson;
import crud.bean.Employee;
import crud.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@org.springframework.web.bind.annotation.RestController
@RequestMapping(value="/rest")
public class RestController {

    @Autowired
    EmployeeService employeeService;


    @GetMapping(value="/emps",produces = {"text/html;charset=UTF-8;","application/json;"})
    public String getEmps(@RequestParam(value = "pageNo",defaultValue = "1") Integer pageNo, Model model){
        //通过pageHelper来实现分页,调用下面方法，传入当前页码和pageSize
        PageHelper.startPage(pageNo,15);
        List<Employee> all = employeeService.getAll();

        //使用pageInfo包装查询后的结果，将pageInfo交给页面就行,第二个参数表示连续显示n页
        PageInfo pageInfo = new PageInfo(all,5);
        Gson gson = new Gson();
//        model.addAttribute("pageInfo", gson.toJson(pageInfo));
        return gson.toJson(pageInfo);
    }


}

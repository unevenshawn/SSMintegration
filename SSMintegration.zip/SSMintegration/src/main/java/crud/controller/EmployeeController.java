package crud.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.gson.Gson;
import crud.bean.Employee;
import crud.bean.Msg;
import crud.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.filter.HiddenHttpMethodFilter;

import java.util.ArrayList;
import java.util.List;


@Controller
public class EmployeeController {

    @Autowired
    EmployeeService employeeService;

    @ResponseBody
    @RequestMapping(value = "gg")
    public String seeGG() {
        return "list";
    }

    //处理"/emps"地址的请求
    //Controller，Service和DAO层，Controller层调用service层
    @RequestMapping("emps")
    public String getEmps(@RequestParam(value = "pn", defaultValue = "1") Integer pageNo, Model model) {
        //通过pageHelper来实现分页,调用下面方法，传入当前页码和pageSize
        PageHelper.startPage(pageNo, 8);
        List<Employee> all = employeeService.getAll();

        //使用pageInfo包装查询后的结果，将pageInfo交给页面就行,第二个参数表示连续显示n页
        PageInfo pageInfo = new PageInfo(all, 5);
        Gson gson = new Gson();
        model.addAttribute("pageInfo", pageInfo);
//        System.out.println("被调用了");
        if (model != null) {
//            System.out.println("model is " + model.getAttribute("pageInfo"));
        }
        return "list";
    }


    @ResponseBody
    @RequestMapping(value = "/jemps", produces = {"text/html;charset=UTF-8;", "application/json;"})
    public Msg getEmpByJson(@RequestParam(value = "pn", defaultValue = "1") Integer pageNo, Model model) {
        //通过pageHelper来实现分页,调用下面方法，传入当前页码和pageSize
        PageHelper.startPage(pageNo, 8);
        List<Employee> all = employeeService.getAll();

        //使用pageInfo包装查询后的结果，将pageInfo交给页面就行,第二个参数表示连续显示n页
        PageInfo pageInfo = new PageInfo(all, 5);
        Gson gson = new Gson();
//        return gson.toJson(Msg.success().add("pageInfo", pageInfo));
        return Msg.success().add("pageInfo", pageInfo);
    }

    //RESTful
    @ResponseBody
    @RequestMapping(value = "/emp", method = RequestMethod.POST)
    public String saveAnEmp(Employee employee) {
        employeeService.save(employee);
        return new Gson().toJson(Msg.success());
    }

    @ResponseBody
    @RequestMapping(value = "/msg", method = RequestMethod.GET)
    public Msg msg() {
        return Msg.success();
    }

    @ResponseBody
    @RequestMapping(value = "/msgf", method = RequestMethod.GET)
    public Msg msf() {
        return Msg.fail();
    }


    /**
     * @param employee 通过update的modal form带着员工的信息发送过来
     * @return
     */
    //改-“/emp/id”-put请求
    @ResponseBody
    //这儿的占位符{}内的实际内容也可以作为员工属性的一部分封装入pojo中
    @RequestMapping(value = "/emp/{empId}", method = RequestMethod.PUT)
    public Msg updateEmp(Employee employee) {
        System.out.println(employee);
        //如果是value = "/emp/{id}"，那么id对应的值无法映射到employee pojo中的empId属性，
        // 而下面这一句的方法是通过主键值查找并更新employee pojo
        int update = employeeService.update(employee);
        //返回值始终是很大的负数，简直了卧槽
//        System.out.println(update);
        return Msg.success();
    }


    //查-“/emp/id”-get请求
    @ResponseBody
    @RequestMapping(value = "/emp/{id}", method = RequestMethod.GET)
    public Employee getEmp(@PathVariable(value = "id") Integer id) {
        Employee emp = employeeService.getEmp(id);
        return emp;
    }


    //查-“/emp/id”-delete请求
    @ResponseBody
    @RequestMapping(value = "/emp/{id}", method = RequestMethod.DELETE)
    public Msg deleteEmp(@PathVariable(value = "id") String s) {
        if (s.contains("-")){
            String[] strings = s.split("-");
            List<Integer> list=new ArrayList<>();
            for (String ssss:strings){
                list.add(Integer.parseInt(ssss));
            }
            employeeService.batchDelEmp(list);
        }else {
            int id = Integer.parseInt(s);
            employeeService.delEmp(id);
        }
        return Msg.success();
    }


}

package crud.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.gson.Gson;
import crud.bean.Employee;
import crud.bean.Msg;
import crud.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;


@Controller
public class EmployeeController {

    @Autowired
    EmployeeService employeeService;

    @ResponseBody
    @RequestMapping(value="gg")
    public  String seeGG(){
        return "list";
    }

    //处理"/emps"地址的请求
    //Controller，Service和DAO层，Controller层调用service层
    @RequestMapping("emps")
    public String getEmps(@RequestParam(value = "pn",defaultValue = "1") Integer pageNo, Model model){
        //通过pageHelper来实现分页,调用下面方法，传入当前页码和pageSize
        PageHelper.startPage(pageNo,8);
        List<Employee> all = employeeService.getAll();

        //使用pageInfo包装查询后的结果，将pageInfo交给页面就行,第二个参数表示连续显示n页
        PageInfo pageInfo = new PageInfo(all,5);
        Gson gson = new Gson();
        model.addAttribute("pageInfo", pageInfo);
        System.out.println("被调用了");
        if (model!=null){
        System.out.println("model is "+model.getAttribute("pageInfo"));}
        return "list";
    }


    @ResponseBody
    @RequestMapping(value = "/jemps",produces = {"text/html;charset=UTF-8;","application/json;"})
    public String getEmpByJson(@RequestParam(value = "pn",defaultValue = "1") Integer pageNo, Model model){
        //通过pageHelper来实现分页,调用下面方法，传入当前页码和pageSize
        PageHelper.startPage(pageNo,8);
        List<Employee> all = employeeService.getAll();

        //使用pageInfo包装查询后的结果，将pageInfo交给页面就行,第二个参数表示连续显示n页
        PageInfo pageInfo = new PageInfo(all,5);
        Gson gson = new Gson();
        return gson.toJson(Msg.success().add("pageInfo",pageInfo));
    }
}

import org.junit.Test;

import java.util.Arrays;

public class NonSpringTest {
    @Test
    public void sst(){
        String s="1-2-3-4";
        String[] split = s.split("-");
        System.out.println(Arrays.toString(split));
    }
}

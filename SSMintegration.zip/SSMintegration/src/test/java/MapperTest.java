import crud.bean.Department;
import crud.bean.Employee;
import crud.dao.DepartmentMapper;
import crud.dao.EmployeeMapper;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;


/**
 * SSM项目推荐使用Spring的test模块
 * 1.导入包
 * 2.@ContextConfiguration指定spring配置文件
 * 3.@RunWith(value = SpringJUnit4ClassRunner.class)//指定用什么模块来进行单元测试
 * 4.@Autowired注入
 */
@RunWith(value = SpringJUnit4ClassRunner.class)//指定用什么模块来进行单元测试
@ContextConfiguration(locations = {"classpath:applicationContext.xml"})
public class MapperTest {

    @Autowired
    Department department;

    @Autowired
    DepartmentMapper departmentMapper;

    @Autowired
    Employee employee;

    @Autowired
    EmployeeMapper employeeMapper;


    @Autowired
    SqlSession sqlSession;

    @Test
    public  void mapperTest(){

        //1.xml创建ApplicationContext
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        //2.从容器中获取mapper
        //System.out.println(department);
        departmentMapper.insert(new Department(null, "测试部"));
        departmentMapper.insert(new Department(null, "开发部"));
        departmentMapper.insert(new Department(null, "市场部"));
        departmentMapper.insert(new Department(null, "工程部"));
        departmentMapper.insert(new Department(null, "客服部"));
        departmentMapper.insert(new Department(null, "行政部"));


        System.out.println(employee);
        employeeMapper.insert(new Employee(null,"Jasmine","F","Jas@min.com",1));
        employeeMapper.insert(new Employee(null,"Gas","M","Gas@gasoline.com",1));

        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ss");
        long l = System.currentTimeMillis();
        String format = dateTimeFormatter.format(ZonedDateTime.now());
        System.out.println("current time =>"+format);
        //批量插入员工，获取可以批量操作的sqlSession。必须要通过sqlsession来获取mapper对象，从而执行相应的操作，否则，其实就是insert语句完全执行若干次，而非批量操作。

        EmployeeMapper mapper = sqlSession.getMapper(EmployeeMapper.class);
        for (int i = 0; i < 50; i++) {
            String substring = UUID.randomUUID().toString().substring(0, 5)+"-"+i;
            mapper.insert(new Employee(null,substring,"M",(substring+"@"+substring+".com"),1));
        }
        for (int i = 0; i < 50; i++) {
            String substring = UUID.randomUUID().toString().substring(1, 3)+"-"+i;
            mapper.insert(new Employee(null,substring,"F",(substring+"@"+substring+".com"),2));
        }
        for (int i = 0; i < 50; i++) {
            String substring = UUID.randomUUID().toString().substring(2, 6)+"-"+i;
            mapper.insert(new Employee(null,substring,"M",(substring+"@"+substring+".com"),3));
        }
        long l1 = System.currentTimeMillis();
        System.out.println("Simple repetition overall time="+(l1-l)/1000);
        String format1 = dateTimeFormatter.format(ZonedDateTime.now());
        System.out.println("current time =>"+format1);

        System.out.println("-------------------------------------------");


        for (int i = 0; i < 50; i++) {
            String substring = UUID.randomUUID().toString().substring(0, 2)+"-"+i;
            mapper.insert(new Employee(null,substring,"F",(substring+"@"+substring+".com"),4));
        }
        for (int i = 0; i < 50; i++) {
            String substring = UUID.randomUUID().toString().substring(0, 5)+"-"+i;
            mapper.insert(new Employee(null,substring,"M",(substring+"@"+substring+".com"),5));
        }
        for (int i = 0; i < 50; i++) {
            String substring = UUID.randomUUID().toString().substring(0, 5)+"-"+i;
            mapper.insert(new Employee(null,substring,"F",(substring+"@"+substring+".com"),6));
        }
        long l2 = System.currentTimeMillis();
        System.out.println("Batch operation overall time="+(l2-l1)/1000);
        String format2 = dateTimeFormatter.format(ZonedDateTime.now());
        System.out.println("current time =>"+format2);
    }



    @Test
    public void selectTest(){
        Employee employee = employeeMapper.selectByPrimaryKeyWithDept(2);
        System.out.println(employee);
        Department department=departmentMapper.selectByPrimaryKey(1);
        System.out.println(department);
    }

}
